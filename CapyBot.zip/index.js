require("dotenv");
require("colors");

const Bot = require("./structures/client");

new Bot();
