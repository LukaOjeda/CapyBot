module.exports = {
  name: "reload",
  alias: [],
  execute: async (client, message, args) => {
    if (message.author.id != process.env.OWNER_ID) return;
    else {
      try {
        switch (args[0]) {
          case "events":
            {
              await client.loadEvents();

              await message.channel.send(`\> Eventos recargados.`);
            }

            break;

          case "handlers":
            {
              await client.loadHandlers();

              await message.channel.send(`\> Handlers recargados.`);
            }

            break;

          case "commands":
          case "cmd":
            {
              await client.loadCommands();
              await client.loadPrefixCommands();

              await message.channel.send(`\> Comandos recargados.`);
            }

            break;

          case "slashCommands":
            {
              await client.loadCommands();

              await message.channel.send(`\> Comandos de slash recargados.`);
            }

            break;

          case "prefixCommands":
            {
              await client.loadPrefixCommands();

              await message.channel.send(`\> Comandos recargados.`);
            }

            break;

          default:
            {
              await client.loadEvents();
              await client.loadHandlers();
              await client.loadCommands();
              await client.loadPrefixCommands();

              await message.clannel.send(`\> Bot recargado.`);
            }

            break;
        }
      } catch (e) {
        return await message.channel.send(
          `\`\`\`Ha ocurrido un error. \n ${e}\`\`\``
        );
      }
    }
  },
};
